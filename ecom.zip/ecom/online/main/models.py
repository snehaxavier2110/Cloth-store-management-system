from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Category(models.Model):
    name = models.CharField(max_length=255, unique=True)
    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=255)
    image = models.ImageField(upload_to='picture')
    price = models.IntegerField()
    category = models.ForeignKey(Category,on_delete= models.CASCADE)
    def __str__(self):
        return self.name
      
class Booking(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    booking_date= models.DateField(auto_now_add=True)
    def __str__(self):
        return self.user.username