from django.shortcuts import render,redirect
from .models import *
from django.contrib import messages
# Create your views here.
def home(request):
    p = Product.objects.all()
    context = { 'key1' : p }
    return render(request,'index.html',context)

def booking_product(request,product_id):
    if request.user.is_authenticated:
        product = Product.objects.get(id=product_id)
        user = request.user
        book = Booking(user=user,product = product)
        book.save()
        messages.info(request,"Product is booked")
        return redirect('/')
    else:
        messages.info(request,"Please login to book product")
        return redirect('login')

def mybook(request):
    user=request.user
    book = Booking.objects.filter(user = user)  
    cont ={'book': book }  
    return render(request,'mybooking.html',cont)
        