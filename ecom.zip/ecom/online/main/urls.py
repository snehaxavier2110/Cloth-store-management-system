from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path("booking/<int:product_id>",views.booking_product, name ='booking'),
    path("mybooking",views.mybook, name="mybooking")
]
